# 📡 MQTT Minifig Monitor

Subscribes to the ME193/minifig MQTT position feed and shows the detected target's position on the LED matrix.


